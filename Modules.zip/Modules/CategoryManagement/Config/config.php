<?php

return [
    'name' => 'CategoryManagement'
];
