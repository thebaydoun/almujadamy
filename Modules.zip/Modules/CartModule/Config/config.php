<?php

return [
    'name' => 'CartModule'
];
