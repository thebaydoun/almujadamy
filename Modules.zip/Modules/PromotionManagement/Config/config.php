<?php

return [
    'name' => 'PromotionManagement'
];
