<?php

return [
    'name' => 'DriverModule'
];
