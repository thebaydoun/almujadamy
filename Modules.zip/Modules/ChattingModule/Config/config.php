<?php

return [
    'name' => 'ChattingModule'
];
