<?php

return [
    'name' => 'ProductModule'
];
